<?php 
  include './koneksi.php';

  $kontak = mysqli_query($koneksi,"SELECT * FROM tb_contact LIMIT 1");
  $data = mysqli_fetch_assoc($kontak);
 ?>
<div class="contact-us"><br><br><br><br><br>
  
    

  
  <div class="container mt-3">
    <h1 class="text-center">Contact Us</h1><hr>
      <div class="row">
          <div class="card-body">
            <div class="contact-method">
                  <i class="fas fa-envelope"></i>
                  <span><?php echo $data['email']; ?></span>
              </div>
          </div>
          <div class="card-body">
               <div class="contact-method">
                  <i class="fas fa-mobile-alt"></i>
                  <span><?php echo $data['telfon']; ?></span>
               </div>
          </div>
          <div class="card-body">
               <div class="contact-method">
                  <i class="fas fa-map-marker-alt"></i>
                  <span><?php echo $data['lokasi']; ?></span>
               </div> 
          </div>
      </div>
      <div class="card-bawah">
        <div class="card mb-4">
          <div class="card-header">
              Profil
            </div>
            <div class="card-body">
              <h5 class="card-title">Vertigi Musik</h5>
              <p class="card-text"><?php echo $data['profil']; ?></p>
            </div>
        </div>
        <div class="card mb-4">
          <div class="card-header">
              Visi & Misi
            </div>
            <div class="card-body">
              <h5 class="card-title">Vertigi Musik</h5>
              <p class="card-text"><?php echo nl2br(str_replace('', '', htmlspecialchars($data['visi_misi']))); ?></p>
            </div>
        </div>
      </div>
    </div>
  </div>
