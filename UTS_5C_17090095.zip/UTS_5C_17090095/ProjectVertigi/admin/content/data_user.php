<?php 
	include '../koneksi.php';

	$user = mysqli_query($koneksi,"SELECT * FROM user");
 ?>
<div class="container-fluid">
	<h3><i class="fas fa-user mr-2 mt-4"></i>Data User</h3><hr>

	<a href="?page=tambah_user" class="btn btn-primary mb-3"><i class="fas fa-plus-circle mr-2"></i>Tambah Data</a>

	<div class="table-responsive">
		<table  id="dtHorizontalVerticalScrollExample" class="table table-bordered table-striped table-sm" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>No</th>
					<th>Username</th>
					<th>Password</th>
					<th>Nama</th>
					<th>Level</th>
					<th>Opsi</th>
				</tr>
			</thead>
				<tr>
					<?php $nomor = 1; ?>
					<?php while ($data = mysqli_fetch_assoc($user)) { ?>
					<td><?php echo $nomor; ?></td>
					<td><?php echo $data['username']; ?></td>
					<td><?php echo $data['password']; ?></td>
					<td><?php echo $data['nama']; ?></td>
					<td><?php echo $data['level']; ?></td>
					<td>
						<a href="?page=ubah_user&id=<?php echo$data['id_user']; ?>" class="btn btn-success"><i class="fas fa-edit"></i></a>
						<a href="?page=hapus_user&id=<?php echo$data['id_user']; ?>" class="btn btn-danger"><i class="fas fa-trash-alt"></i></a>
					</td>
				</tr>
				<?php 
					$nomor++;
				} ?>
		</table>
	</div>
</div>