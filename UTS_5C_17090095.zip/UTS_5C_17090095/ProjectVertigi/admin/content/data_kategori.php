<?php 
	include '../koneksi.php';

	$kategori = mysqli_query($koneksi,"SELECT * FROM tb_kategori");
 ?>
<div class="container-fluid">
 	<h3><i class="fas fa-briefcase mr-2 mt-4"></i>Data Kategori Alat Musik</h3><hr>

 	<a href="?page=tambah_kategori" class="btn btn-primary mb-3"><i class="fas fa-plus-circle mr-2"></i>Tambah Data</a>

	<div class="table-responsive">
		<table  id="dtHorizontalVerticalScrollExample" class="table table-bordered table-striped table-sm" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>No</th>
					<th>Kategori Alat Musik</th>
					<th>Opsi</th>
				</tr>
			</thead>
				<tr>
					<?php $nomor = 1; ?>
					<?php while ($data = mysqli_fetch_assoc($kategori)) { ?>
					<td><?php echo $nomor; ?></td>
					<td><?php echo $data['kategori']; ?></td>
					<td>
						<a href="?page=ubah_kategori&id=<?php echo $data['id_kategori']; ?>" class="btn btn-success"><i class="fas fa-edit"></i></a>
						<a href="?page=hapus_kategori&id=<?php echo $data['id_kategori']; ?>" class="btn btn-danger"><i class="fas fa-trash-alt"></i></a>
					</td>
					
				</tr>
				<?php 
					$nomor++;
				} ?>
		</table>
	</div>
</div>
      