<?php 

	$content = (isset($_GET["page"])) ? $_GET["page"] : "";

	switch ($content) {
		case 'data_user':
            echo "<title>Data User</title>";
            require 'content/data_user.php';
            break;
        	case 'tambah_user':
            	echo "<title>Data User</title>";
            	require 'form/tambah_user.php';
            	break;
            case 'ubah_user':
            	echo "<title>Data User</title>";
            	require 'form/ubah_user.php';
            	break;
            case 'hapus_user':
            	echo "<title>Data User</title>";
            	require 'form/hapus_user.php';
            	break;

        case 'data_produk':
            echo "<title>Data Produk</title>";
            require 'content/data_produk.php';
            break;
        	case 'tambah_produk':
            	echo "<title>Data Produk</title>";
            	require 'form/tambah_produk.php';
            	break;
            case 'ubah_produk':
            	echo "<title>Data Produk</title>";
            	require 'form/ubah_produk.php';
            	break;
            case 'hapus_produk':
            	echo "<title>Data Produk</title>";
            	require 'form/hapus_produk.php';
            	break;

            case 'data_kategori':
            echo "<title>Data kategori</title>";
            require 'content/data_kategori.php';
            break;
            case 'tambah_kategori':
                  echo "<title>Data kategori</title>";
                  require 'form/tambah_kategori.php';
                  break;
            case 'ubah_kategori':
                  echo "<title>Data kategori</title>";
                  require 'form/ubah_kategori.php';
                  break;
            case 'hapus_kategori':
                  echo "<title>Data kategori</title>";
                  require 'form/hapus_kategori.php';
                  break;

            case 'data_contact':
            echo "<title>Data Contact</title>";
            require 'content/data_contact.php';
            break;
            case 'tambah_contact':
                  echo "<title>Data Contact</title>";
                  require 'form/tambah_contact.php';
                  break;
            case 'ubah_contact':
                  echo "<title>Data Contact</title>";
                  require 'form/ubah_contact.php';
                  break;
            case 'hapus_contact':
                  echo "<title>Data Contact</title>";
                  require 'form/hapus_contact.php';
                  break;


		
		default:
            echo "<title>Dashboard</title>";
            require 'content/dashboard.php';
            break;
	}

 ?>