<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

 <!--  <title>Admin Loker</title> -->

  <!-- Bootstrap core CSS -->
  <link rel="shortcut icon" type="text/css" href="images/icon.ico">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="vendor/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/responsive.bootstrap4.min.css">
  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

</head>