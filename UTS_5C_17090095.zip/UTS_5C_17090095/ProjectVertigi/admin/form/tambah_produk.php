<div class="container-fluid">
	<h3><i class="fas fa-user mr-2 mt-4"></i>Tambah Data Produk</h3><hr><hr>
	
	<?php 

	$kategori =mysqli_query($koneksi, "SELECT * FROM tb_kategori");
			

		If (isset($_POST['save'])) 
		 	{
		 		// include '../koneksi.php';
		 		$nama = $_POST['nama'];
		 		$deskripsi = $_POST['deskripsi'];
		 		$harga = $_POST['harga'];
		 		// $Kategori = mysqli_query($conn,"SELECT * FROM tb_kategori");
		 		$kategori = $_POST['kategori'];
		 		$gambar = $_FILES['gambar']['name'];
		 		$temp = $_FILES['gambar']['tmp_name'];
		 		move_uploaded_file($temp,"../gambar/$gambar");
		 		
		 		$query = "INSERT INTO tb_produk (nama,deskripsi,harga,kategori,gambar)
		 				VALUES ('$nama','$deskripsi','$harga','$kategori','$gambar')";
		 		$save = mysqli_query($koneksi,$query);

		 		if ($save) {
		 			echo "<div class=\"alert alert-success\" role=\"alert\">Berhasil Disimpan</div>";
					echo "<script>var timer = setTimeout(function()
					{ window.location= '?page=data_produk'}, 1000);
				</script>";
				}else{
					echo "<div class=\"alert alert-danger\" role=\"alert\">Gagal disimpan</div>";
					echo "<script>var timer = setTimeout(function()
					{ window.location= '?page=tambah_produk'}, 1000);
				</script>";
		 		}
		 	}

	?>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label>Nama</label>
				<input type="text" class="form-control" name="nama" required>
			</div>
			<div class="form-group">
				<label>Deskripsi</label>
				<input type="text" class="form-control" name="deskripsi" required>
			</div>
			<div class="form-group">
				<label>Harga</label>
				<input type="text" class="form-control" name="harga" required>
			</div>
			<div class="form-group">
				<label for="inputKategori">Kategori</label>
			      		<select id="inputKategori" class="form-control" name="kategori" required>
					        <option value="">--select--</option>
					        <?php while ($kat = mysqli_fetch_assoc($kategori)) { ?>
					        <option value="<?php echo $kat['kategori']; ?>"><?php echo $kat['kategori']; ?></option>
					        <?php } ?>
					    </select>
			</div>
			<!-- <div class="form-group">
				<label>Kategori</label>
				<input type="text" class="form-control" name="kategori">
			</div> -->
			<div class="form-group">
	    	 <label for="validationDefault10">Gambar</label><br>
	    	 <input type="file" class="form-control-file" name="gambar" id="inputimg" required>
	  	    </div>
			<<!-- div class="form-group">
				<label>Level</label>
				<select required="" class="form-control" name="level" required>
					<option>--Plih Salah Satu--</option>
					<option>Admin</option>
					<option>Guest</option>
				</select>
			</div> -->
			<button class="btn btn-success" name="save">Simpan</button>
		</form>
</div>