<div class="container-fluid">
 	<h3><i class="fas fa-briefcase mr-2 mt-4"></i>Ubah Data Kategori Alat Musik</h3><hr><hr>

 	<?php 
			
			If (isset($_POST['edit'])) 
		 	{
		 		$kategori = $_POST['kategori'];
		 		
		 		
		 		$query = "UPDATE tb_kategori SET kategori = '$kategori' 
		 				  WHERE id_kategori = '$_GET[id]'";
		 		$save = mysqli_query($koneksi,$query);

		 		if ($save) {
		 			// echo "<script>alert('Data Berhasil Diubah');</script>";
		 			echo "<div class=\"alert alert-success\" role=\"alert\">Berhasil disimpan</div>";
					echo "<script>var timer = setTimeout(function()
					{ window.location= '?page=data_kategori'}, 1000);
				</script>";
				}else{
					// echo "<script>alert('Data Gagal Diubah');</script>";
					echo "<div class=\"alert alert-danger\" role=\"alert\">Gagal disimpan</div>";
					echo "<script>var timer = setTimeout(function()
					{ window.location= '?page=ubah_kategori'}, 1000);
				</script>";
		 		}
		 	}

		?>

		<?php 
		
			$ambil = "SELECT * FROM tb_kategori WHERE id_kategori='$_GET[id]'";
			$edit = mysqli_query($koneksi,$ambil);
			$data = mysqli_fetch_assoc($edit);


 		?>	

	<form method="post" enctype="multipart/form-data" action="">
			<div class="form-group">
				<label>Keahlian</label>
				<input type="text" class="form-control" name="kategori" value="<?php echo $data
				['kategori']; ?>" required>
			</div>
			<button class="btn btn-success" name="edit">Simpan</button>
	</form>

</div>