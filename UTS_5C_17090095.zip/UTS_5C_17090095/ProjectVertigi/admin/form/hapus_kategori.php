<div class="container-fluid">
 	<h3><i class="fas fa-briefcase mr-2 mt-4"></i>Data Kategori</h3><hr>
<?php  
	
	require '../koneksi.php';

	$query = "DELETE FROM tb_kategori WHERE id_kategori='$_GET[id]'";
	$delete = mysqli_query($koneksi,$query);

	if ($delete) {
		echo "<div class=\"alert alert-success\" role=\"alert\">Berhasil dihapus</div>";
		echo "<script>var timer = setTimeout(function()
			{ window.location= '?page=data_kategori'}, 500);
			</script>";
	}else{
		// echo "<script>alert('Data Gagal Dihapus');</script>";
		echo "<div class=\"alert alert-danger\" role=\"alert\">Gagal dihapus</div>";
		echo "<script>var timer = setTimeout(function()
		{ window.location= '?page=data_kategori'}, 500);
		</script>";
	}

 ?>
</div>