<div class="container-fluid">
	<h3><i class="far fa-id-card mr-2 mt-4"></i>Data Contact Us</h3><hr>
<?php  
	
	require '../koneksi.php';

	$query = "DELETE FROM tb_contact WHERE id_contact='$_GET[id]'";
	$delete = mysqli_query($koneksi,$query);

	if ($delete) {
		// echo "<script>alert('Data Berhasil Dihapus');</script>";
		echo "<div class=\"alert alert-success\" role=\"alert\">Berhasil dihapus</div>";
		echo "<script>var timer = setTimeout(function()
			{ window.location= '?page=data_contact'}, 500);
			</script>";
	}else{
		// echo "<script>alert('Data Gagal Dihapus');</script>";
		echo "<div class=\"alert alert-danger\" role=\"alert\">Gagal dihapus</div>";
		echo "<script>var timer = setTimeout(function()
		{ window.location= '?page=data_contact'}, 500);
		</script>";
	}

 ?>
</div>